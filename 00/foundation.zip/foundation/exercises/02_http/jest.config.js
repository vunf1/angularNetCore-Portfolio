module.exports = {
	verbose: true,
	testRegex: 'simple.test.js'
}

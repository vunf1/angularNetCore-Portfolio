
'use strict'

module.exports = {
	verbose: true,
}

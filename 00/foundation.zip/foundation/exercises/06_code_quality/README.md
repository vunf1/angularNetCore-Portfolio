# Assignment Template

This repository contains the base files for the assignment. To make use of this carry out the following steps:

1. Fork this repository but change its name (replace `xxx` with your university username):
    1. If this is your original assignment, `xxx-coursework`.
    2. If this is your resit assignment code, `xxx-resit`.
2. Replace the contents of this file with the details of the topic you have been assigned.

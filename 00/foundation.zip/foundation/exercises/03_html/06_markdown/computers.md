
# 80s Computers

Here is a list of the best computers from the 1980s.

1. Commodore 64
2. ZX Spectrum

| Computer    | Year  |
| ----------- | ----: |
| Commodore64 | 1982  |
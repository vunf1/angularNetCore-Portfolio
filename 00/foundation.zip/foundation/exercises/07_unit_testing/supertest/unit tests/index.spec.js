
'use strict'

const request = require('supertest')
const status = require('http-status-codes')

const server = require('../index.js')

beforeAll( async() => console.log('Jest starting!'))

describe('GET /', done => {
	// tests go here
})

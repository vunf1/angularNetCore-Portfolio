#!/usr/bin/env node
/* eslint no-var: 0 */

'use strict'

console.log(name)

var name = 'John Doe'

console.log(name)

name = 'Peter Pan'

console.log(name)

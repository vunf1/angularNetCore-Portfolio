#!/usr/bin/env node

'use strict'

const Koa = require('koa')
const app = new Koa()
const Wwbsocket = require('koa-websocket')
const route = require('koa-route')

const app = websocket(app)

// const socket = new Websocket()
// const router = require('koa-router')

// const http = router()
// const we = router()

// http.get('/', async ctx => {

// })




'use strict'

/* eslint no-unused-vars: 0 */

const messages = ( function() {
	let msgs = []
	return {
		extractData: payloadString => {
			return payloadString
		},
		add: data => {
			if(data === '') throw new Error('empty string parameter')
			msgs[0] = data
		},
		get html() {
			let html = ''
			for(const msg of msgs) {
				html += `<h2>${msg}</h2>`
			}
			return html
		},
		get all() {
			return msgs
		},
		get count() {
			return msgs.length
		},
		clear: () => {
			msgs = []
		}
	}
})()

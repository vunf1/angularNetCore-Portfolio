
'use strict'

/* eslint no-undef: 0 */

describe('check encapsulation', () => {
	it('check message array is private', () => {
		try {
			const data = msgs
			expect(1).toBe(0) // this line should not be run!
			console.log(data)
		} catch(err) {
			expect(err.message).toBe('Can\'t find variable: msgs')
		}
	})
})

describe('properties', () => {

	describe('html', () => {

		beforeEach( () => messages.clear())

		it('when adding a single message', () => {
			messages.add('hello world')
			const html = messages.html
			expect(html).toBe('<h2>hello world</h2>')
		})

		it('when adding multiple messages', () => {
			messages.add('hello')
			messages.add('goodbye')
			const html = messages.html
			expect(html).toBe('<h2>goodbye</h2>')
		})

	})

	describe('all', () => {

		beforeEach( () => messages.clear())

		it('when adding a single message', () => {
			messages.add('hello world')
			const msgs = messages.all
			expect(Array.isArray(msgs)).toBeTruthy()
			expect(msgs.length).toBe(1)
		})

		it('when adding multiple messages', () => {
			messages.add('hello')
			messages.add('goodbye')
			const msgs = messages.all
			expect(Array.isArray(msgs)).toBeTruthy()
			expect(msgs.length).toBe(1)
		})

	})

	describe('count', () => {

		it('when adding a single message', () => {
			messages.add('hello world')
			expect(messages.count).toBe(1)
		})

		it('when adding multiple messages', () => {
			messages.add('hello')
			messages.add('goodbye')
			expect(messages.count).toBe(1)
		})

	})

})

describe('methods', () => {
	describe('extractData', () => {

		it('returns the message', () => {
			const msg = messages.extractData('Hello World')
			expect(msg).toBe('Hello World')
		})

	})

	describe('addMessage', () => {

		beforeEach( () => messages.clear())

		it('add a single message', () => {
			messages.add('hello world')
			expect(messages.count).toBe(1)
			const msgs = messages.all
			expect(msgs[0]).toBe('hello world')
		})

		it('adding multiple messages', () => {
			messages.add('hello')
			messages.add('goodbye')
			expect(messages.count).toBe(1)
			const msgs = messages.all
			expect(msgs[0]).toBe('goodbye')
		})

		it('adding an empty message should throw an error', () => {
			try {
				messages.add('')
				expect(1).toBe(0) // this line should not be run!
			} catch(err) {
				expect(err.message).toBe('empty string parameter')
			}
		})

	})

	describe('clear', () => {

		it('clearing a single message', () => {
			messages.add('hello world')
			messages.clear()
			expect(messages.count).toBe(0)
		})

		it('clearing multiple messages', () => {
			messages.add('hello')
			messages.add('goodbye')
			messages.clear()
			expect(messages.count).toBe(0)
		})

	})

})


'use strict'

/* eslint no-undef: 0, no-magic-numbers: 0 */

const client = new Messaging.Client('broker.mqttdashboard.com', 8000, `myclientid_${parseInt(Math.random() * 100, 10)}`)

client.onConnectionLost = responseObject => console.log(`connection lost: ${responseObject.errorMessage}`)
client.onMessageArrived = message => {
	console.log(message)
	console.log(`Topic: ${message.destinationName} Payload: ${message.payloadString}`)
	try {
		const msg = messages.extractData(message.payloadString)
		messages.add(msg)
		document.querySelector('div').innerHTML = messages.html
	} catch(err) {
		console.log(err.message)
	}
}

const publish = (payload, topic, qos) => {
	const message = new Messaging.Message(payload)
	message.destinationName = topic
	message.qos = qos
	client.send(message)
}

const options = {
	timeout: 3,
	onSuccess: () => {
		console.log('connected')
		client.subscribe('cu/#', {qos: 2})
		console.log('Subscribed')
	},
	onFailure: message => console.log(`Connection failed: ${message.errorMessage}`)
}

client.connect({
	onSuccess: onConnect,
	userName: 'Username',
	password: 'password'
})

document.addEventListener('DOMContentLoaded', () => {
	console.log('page loaded')
	document.querySelector('input').onkeyup = e => {
		console.log('keyup')
		if(e.which === 13) {
			console.log('enter key pressed')
			const payload = document.querySelector('input').value
			publish(payload,'cu/chat',2)
			document.querySelector('input').value = ''
		}
	}
})

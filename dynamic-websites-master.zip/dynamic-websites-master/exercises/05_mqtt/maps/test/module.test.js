
'use strict'

/* eslint no-undef: 0 */

describe('check encapsulation', () => {
	it('check markers array is private', () => {
		try {
			const data = markers
			expect(1).toBe(0) // this line should not be run!
			console.log(data)
		} catch(err) {
			expect(err.message).toBe('markers is not defined')
		}
	})

	describe('properties', () => {

		describe('all', () => {

			it('check for an empty array', () => {
				const pins = maps.all
				console.log(pins)
				expect(Array.isArray(pins)).toBeTruthy()
				expect(pins.length).toBe(0)
			})

		})

	})

	describe('methods', () => {

		describe('extractData', () => {

			it('extracts complete data', () => {
				const str = '{"lat": 52.4082, "lon": -1.5071, "label": "cathedral"}'
				const data = maps.extractData(str)
				expect(typeof data).toBe('object')
				expect(Object.keys(data).length).toBe(3)
				expect(data.lat).toBe(52.4082)
				expect(data.lon).toBe(-1.5071)
				expect(data.label).toBe('cathedral')
			})

			it('throw error if parameter is not a json string', () => {
				try {
					maps.extractData('hello world')
					expect(0).toBe(1)
				} catch(err) {
					expect(err.message).toBe('parameter is not a json string')
				}
			})

		})

		describe('addMarker', () => {

		})

		describe('scale', () => {

		})

	})
})

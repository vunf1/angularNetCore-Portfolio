
'use strict'

const maps = (function() {

	const markers = []

	return {
		extractData: payloadString => {
			try {
				const data = JSON.parse(payloadString)
				return data
			} catch(err) {
				if(err.message === 'Unexpected token h in JSON at position 0') {
					throw new Error('parameter is not a json string')
				}
				throw new Error(err) // we need to propagate all other errors
			}
		},
		addMarker: data => {
			const latLng = new google.maps.LatLng(data.lat, data.lon)
			const mkr = { position: latLng, title: data.label }
			const marker = new google.maps.Marker(mkr)
			markers.push(marker)
			return marker
		},
		get all() {
			return markers
		},
		scale: map => {
			let bounds = new google.maps.LatLngBounds()
			const markers = maps.all
			for (var i = 0; i < markers.length; i++) {
				markers[i].setMap(map)
				bounds.extend(markers[i].getPosition())
			}
			map.fitBounds(bounds)
			console.log(`zoom level: ${map.getZoom()}`)
			if(map.getZoom() > 16) map.setZoom(16)
			const currentBounds =  map.getBounds()
			console.log(JSON.stringify(currentBounds, null, 2))
			return currentBounds
		}
	}

})()

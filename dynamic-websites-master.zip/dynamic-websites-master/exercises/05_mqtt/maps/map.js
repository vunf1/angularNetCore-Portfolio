
'use strict'

let map

function loadMap() {
	const mapOptions = {
		center:new google.maps.LatLng(52.4080, -1.5104),
		zoom:12, 
		mapTypeId:google.maps.MapTypeId.ROADMAP
	}
	map = new google.maps.Map(document.getElementById('sample'),mapOptions)
	if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition( position => {
			console.log(`current location: ${position.coords.latitude}, ${position.coords.longitude}`)
			map.setCenter(new google.maps.LatLng(position.coords.latitude, position.coords.longitude))
		})
	}
}

google.maps.event.addDomListener(window, 'load', loadMap)

// ------- MQTT STUFF

const client = new Messaging.Client('broker.mqttdashboard.com', 8000, `myclientid_${parseInt(Math.random() * 100, 10)}`)

client.onConnectionLost = responseObject => console.log(`connection lost: ${responseObject.errorMessage}`)

client.onMessageArrived = message => {
	const data = maps.extractData(message.payloadString)
	maps.addMarker(data)
	maps.scale(map)
	//scaleMap()
}

const options = {
	timeout: 3,
	onSuccess: () => {
		console.log('connected')
		client.subscribe('cov/map', {qos: 2})
		console.log('Subscribed')
	},
	onFailure: message => console.log(`Connection failed: ${message.errorMessage}`)
}

client.connect(options)

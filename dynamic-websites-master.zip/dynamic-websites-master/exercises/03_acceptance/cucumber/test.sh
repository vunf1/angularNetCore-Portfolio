#!/usr/bin/env bash

node index.js&
node_modules/.bin/jest --runInBand --detectOpenHandles acceptance\ tests/*
kill %1

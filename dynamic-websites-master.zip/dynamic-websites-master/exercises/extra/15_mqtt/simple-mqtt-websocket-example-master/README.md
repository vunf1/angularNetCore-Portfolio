
This is example code for [this blog post](http://jpmens.net/2014/07/03/the-mosquitto-mqtt-broker-gets-websockets-support/).

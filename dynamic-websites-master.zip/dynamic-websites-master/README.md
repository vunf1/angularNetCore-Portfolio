
# Dynamic Websites

This teaching material builds on that in the **Foundation** labs and these should be completed before starting this.

## About this Github repository

This Github repository is a collaborative work between Coventry University and Helsinki Metropolia University of Applied Sciences. The repository was initially set up by Mark Tyers who contributed initial drafts of most exercises. During the 1st semester of the 15-16 academic year, this set of material was used by Erja, Vesa and colleagues, who made substantial improvements.

Additions were made by Jianhua Yang between 2016-17 after which the module was taken over by Mark Tyers for the 2018 delivery.

Tagged releases have been created at the end of each semester of delivery to act as snapshots of the materials. These can be accessed in GitHub under the **Releases** tab.

```shell
$ git tag -a 1415OCTMAY 582f65c -m '1415OCTMAY'
$ git push origin 1415OCTMAY
```

Deleting tags (local then remote).

```shell
$ git tag --delete 582f65c
$ git push -delete origin 582f65c
```

Notes:

Express vs Koa vs Hapi: https://www.sitepoint.com/express-koa-hapi/

Good article on Koa covering useful bits such as global error handling: https://scotch.io/tutorials/introduction-to-koa-the-future-of-express
